return {
	["src/game/action/view/action_open_server_gift_window.luac"] = {
		file = "action_open_server_gift_window.luac", ver = 1, size = 12673, },
	["src/game/newfirstcharge/view/bigfirstcharge_window.luac"] = {
		file = "bigfirstcharge_window.luac", ver = 1, size = 6745, },
	["src/config/login_days_new_data.luac"] = {
		file = "login_days_new_data.luac", ver = 1, size = 2673, },
}